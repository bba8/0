# 一个简洁大气的导航网站源码

一个纯静态的导航网站源码 黑色简洁大气 演示地址已失效


# 关于使用  

1.因为个人能力有限，如需要使用本源码，请直接编辑index.html文件

2.links.html里的多说评论框请替换成自己的ID

3.因为是纯静态网站，其他没有啦

# 截图

 ![image](https://github.com/yiyeticms/yiyeti_daohang/blob/master/%E6%BC%94%E7%A4%BA%E5%9B%BE.png)
